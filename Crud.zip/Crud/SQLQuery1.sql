Create table DS_Salesman
(
	SalesmanId int identity(1,1),
	SalesmanFirstName varchar(30),
	SalesmanMiddleName varchar(30),
	SalesmanLastName varchar(30),
	Commission decimal(10,2),
	IsWorking int,
	OnLeave int,
	Gender varchar(10),
	Age int check (Age>=18 and Age<100) not null,
	Email varchar(30),
	DOB varchar(10),
	Customer_No decimal(10),
	Region varchar(15),
	ItemCategory varchar(25),
	Quantity int,
	Price decimal(8,2),
	PhoneNumber varchar(10),
	AlternativeNumber varchar(10),
	CurrentAddress varchar(150),
	PermanentAddres varchar(150),
	State_ varchar(50),
	City varchar(50),
	Country varchar(30),
	constraint pk_Salesman primary key (SalesmanId),	
);

select * from DS_Salesman;

drop table DS_Salesman;

insert into DS_Salesman
(SalesmanFirstName,SalesmanMiddleName,SalesmanLastName,Commission,IsWorking,OnLeave,Gender,Age,Email,PhoneNumber,AlternativeNumber,CurrentAddress,PermanentAddres,State_,City,Country)
values
('Mohit','Chandra','joshi',531,1,0,'male',23,'mj74518@gmail.com','9876554453','7865452312','fhdfhd','dfsdfds','uttarakhand','haldwani','india');

truncate table DS_Salesman

CREATE TABLE state_list (
  id int NOT NULL identity(1,1),
  state varchar(50) NOT NULL,
  constraint pk_state_list primary key(id)
);

INSERT INTO state_list (state) 
VALUES
('ANDAMAN AND NICOBAR ISLANDS'),
('ANDHRA PRADESH'),
('ARUNACHAL PRADESH'),
('ASSAM'),
('BIHAR'),
('CHATTISGARH'),
('CHANDIGARH'),
('DAMAN AND DIU'),
('DELHI'),
('DADRA AND NAGAR HAVELI'),
('GOA'),
('GUJARAT'),
('HIMACHAL PRADESH'),
('HARYANA'),
('JAMMU AND KASHMIR'),
('JHARKHAND'),
('KERALA'),
('KARNATAKA'),
('LAKSHADWEEP'),
('MEGHALAYA'),
('MAHARASHTRA'),
('MANIPUR'),
('MADHYA PRADESH'),
('MIZORAM'),
('NAGALAND'),
('ORISSA'),
('PUNJAB'),
('PONDICHERRY'),
('RAJASTHAN'),
('SIKKIM'),
('TAMIL NADU'),
('TRIPURA'),
('UTTARAKHAND'),
('UTTAR PRADESH'),
('WEST BENGAL'),
('TELANGANA');
﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;
using Crud.Models;

namespace Crud.DataModel.Operation
{
	public class DbOperation
	{
        public int AddSalesman(Modeldb man)
        {            
                using (var data = new DBEntities())
                {
                    DS_Salesman user = new DS_Salesman()
                    {
                        SalesmanFirstName = man.SalesmanFirstName.Trim(),
                        SalesmanMiddleName = man.SalesmanMiddleName,
                        SalesmanLastName = man.SalesmanLastName.Trim(),
                        Age = man.Age,
                        Gender = man.Gender.Trim(),
                        Email = man.Email.Trim(),
                        IsWorking = 1,
                        OnLeave = 0
                    };
                    data.DS_Salesman.Add(user);
                    data.SaveChanges();
                    return user.SalesmanId;
                
                }    
        }

        public List<Modeldb> GetAllActive()
        {
            using( var data = new DBEntities())
            {
                var AllUsers = data.DS_Salesman.Where(x=>(x.IsWorking == 1) & (x.OnLeave==0)).Select(x => new Modeldb()
                {
                    SalesmanId=x.SalesmanId,
                    SalesmanFirstName = x.SalesmanFirstName,
                    SalesmanMiddleName = x.SalesmanMiddleName,
                    SalesmanLastName = x.SalesmanLastName,
                    Age = x.Age,
                    Commission = x.Commission,
                    Email = x.Email,
                    Gender = x.Gender
                }).ToList();

                return AllUsers;
            }
        }

        public List<Modeldb> GetAllDeactive()
        {
            using (var data = new DBEntities())
            {
                var AllUsers = data.DS_Salesman.Where(x => (x.IsWorking == 0) & (x.OnLeave == 0)).Select(x => new Modeldb()
                {
                    SalesmanId = x.SalesmanId,
                    SalesmanFirstName = x.SalesmanFirstName,
                    SalesmanMiddleName = x.SalesmanMiddleName,
                    SalesmanLastName = x.SalesmanLastName,
                    Age = x.Age,
                    Commission = x.Commission,
                    Email = x.Email,
                    Gender = x.Gender
                }).ToList();

                return AllUsers;
            }
        }

        public Modeldb GetSalesman(int id)
        {
            using(var data = new DBEntities())
            {
                var SingleUser = data.DS_Salesman.Where(x=>x.SalesmanId == id).Select(x=> new Modeldb()
                {
                    SalesmanId=x.SalesmanId,
                    SalesmanFirstName = x.SalesmanFirstName,
                    SalesmanMiddleName = x.SalesmanMiddleName,
                    SalesmanLastName = x.SalesmanLastName,
                    Age = x.Age,
                    Email = x.Email,
                    Gender = x.Gender,
                    Commission = x.Commission,
                    Region = x.Region,
                    DOB = x.DOB,
                    Customer_No = x.Customer_No,
                    ItemCategory = x.ItemCategory,
                    Quantity =x.Quantity,
                    Price = x.Price,
                    PhoneNumber = x.PhoneNumber,
                    AlternativeNumber = x.AlternativeNumber,
                    Country = x.Country,
                    State_ = x.State_,
                    City = x.City,
                    CurrentAddress = x.CurrentAddress,
                    PermanentAddres = x.PermanentAddres

                }).FirstOrDefault();

                return SingleUser;
                
            }
        }

        public int EditSalesman(int id,Modeldb man)
        {
            using (var Edit = new DBEntities())
            {
                var edit = Edit.DS_Salesman.FirstOrDefault(x => x.SalesmanId == id);
                if (edit != null)
                {
                    edit.SalesmanFirstName = man.SalesmanFirstName.Trim();
                    edit.SalesmanMiddleName = man.SalesmanMiddleName.Trim();
                    edit.SalesmanLastName = man.SalesmanLastName.Trim();
                    edit.Age = man.Age;
                    edit.Gender = man.Gender.Trim();
                    edit.Email = man.Email.Trim();
                    edit.Commission = man.Commission;
                    edit.Customer_No = man.Customer_No;
                    edit.DOB = man.DOB;
                    edit.ItemCategory = man.ItemCategory;
                    edit.Region = man.Region;
                    edit.Quantity = man.Quantity;
                    edit.Price = man.Price;
                    edit.PhoneNumber = man.PhoneNumber;
                    edit.AlternativeNumber = man.AlternativeNumber;
                    edit.CurrentAddress = man.CurrentAddress.Trim();
                    edit.PermanentAddres = man.PermanentAddres.Trim();
                    edit.State_ = man.State_.Trim();
                    edit.City = man.City.Trim();
                    edit.Country = man.Country.Trim();
                    edit.IsWorking = 1;
                    edit.OnLeave = 0; ;
                }
                Edit.SaveChanges();
                return edit.SalesmanId;
            }
        }

        public int DeleteSalesman(int id)
        {
            using (var Del = new DBEntities())
            {
                var DelUser = Del.DS_Salesman.FirstOrDefault(x => x.SalesmanId == id);
                if (DelUser!=null)
                {
                    DelUser.IsWorking = 0;
                    Del.SaveChanges();
                }
                return DelUser.SalesmanId;
            }
        }

        public int EnableSalesman(int id)
        {
            using (var Del = new DBEntities())
            {
                var DelUser = Del.DS_Salesman.FirstOrDefault(x => x.SalesmanId == id);
                if (DelUser != null)
                {
                    DelUser.IsWorking = 1;
                    Del.SaveChanges();
                }
                return DelUser.SalesmanId;
            }
        }

    }
}
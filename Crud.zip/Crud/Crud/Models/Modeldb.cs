﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Crud.Models
{
    public class Modeldb
    {
        [Key]
        public int SalesmanId { get; set; }
        [Required]
        [Display(Name = "First Name")]
        public string SalesmanFirstName { get; set; }

        [Display(Name = "Middle Name")]
        public string SalesmanMiddleName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string SalesmanLastName { get; set; }

        [Required]
        [Display(Name = "Commission")]
        [DataType(DataType.Currency)]
        public Nullable<decimal> Commission { get; set; }

        public Nullable<int> IsWorking { get; set; }

        public Nullable<int> OnLeave { get; set; }

        [Required]
        [Display(Name = "Gender")]
        [DataType(DataType.Text)]
        public string Gender { get; set; }

        [Required]
        [Display(Name = "Age")]
        [Range(18, 100)]
        public int Age { get; set; }

        [Required]
        [Display(Name = "Email Address")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Primary Number")]
        [MinLength(10)]
        [DataType(DataType.PhoneNumber)]

        //[RegularExpression(@"^[0-9]$")]
        public string PhoneNumber { get; set; }

        [Required]
        [Display(Name = "Secondary Number")]
        [DataType(DataType.PhoneNumber)]
        [MinLength(10)]
        //[RegularExpression(@"^[0-9]$")]
        public string AlternativeNumber { get; set; }

        [Required]
        [Display(Name = "Current Address")]
        public string CurrentAddress { get; set; }

        [Required]
        [Display(Name = "Permanent Address")]
        public string PermanentAddres { get; set; }

        [Required]
        [Display(Name = "Country Name")]
        public string Country { get; set; }

        [Required]
        [Display(Name = "State Name")]
        public string State_ { get; set; }

        [Required]
        [Display(Name = "City Name")]
        public string City { get; set; }

        [Required]
        [Display(Name = "Target Total Customer")]
        public Nullable<decimal> Customer_No { get; set; }

        [Required]
        [Display(Name ="Region")]
        public string Region { get; set; }

        [Required]
        [Display(Name ="Item Category")]
        [DataType(DataType.Text)]
        public string ItemCategory { get; set; }
        
        [Required]
        [Display(Name ="Quantiy")]
        public Nullable<int> Quantity { get; set; }
        
        [Required]
        [Display(Name ="Price/Item")]
        [DataType(DataType.Currency)]
        public Nullable<decimal> Price { get; set; }

        [Required]
        [Display(Name ="Date of Birth")]
        [DataType(DataType.Date)]
        public string DOB { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Crud.Models;
using Crud.DataModel.Operation;

namespace Crud.Controllers
{
    public class HomeController : Controller
    {
        DbOperation Data = null;

        public HomeController()
        {
            Data = new DbOperation();
        }

        public ActionResult Create()
        {
            return View();
        }
        // Post: Home
        [HttpPost]
        public ActionResult Create(Modeldb data)
        {
            var usr = Data.AddSalesman(data);
            if (ModelState.IsValid)
            {
                ModelState.Clear();
                ViewBag.success = "Record Inserted!!";
            }
            return View();
        }

        public ActionResult GetAll()
        {
            var data = Data.GetAllActive();
            return View(data);
        }

        public ActionResult GetDeactive()
        {
            var data = Data.GetAllDeactive();
            return View(data);
        }

        public ActionResult Detail(int id)
        {
            var getuser = Data.GetSalesman(id);
            return View(getuser);
        }

        public ActionResult Edit(int id)
        {
            var getuser = Data.GetSalesman(id);
            return View(getuser);
        }
        [HttpPost]
        public ActionResult Edit(Modeldb data)
        {
            if (ModelState.IsValid)
            {
                Data.EditSalesman(data.SalesmanId, data);
            }
            return RedirectToAction("GetAll");
        }

        public ActionResult Delete(int id)
        {
            var del = Data.DeleteSalesman(id);
            return RedirectToAction("GetAll"); ;
        }

        public ActionResult Enable(int id)
        {
            var del = Data.EnableSalesman(id);
            return RedirectToAction("GetAll"); ;
        }
    }
}